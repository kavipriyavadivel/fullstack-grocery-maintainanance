package com.example.groceryMaintananceBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroceryMaintananceBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(GroceryMaintananceBackendApplication.class, args);
	}

}
