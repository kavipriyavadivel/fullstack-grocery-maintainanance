package com.example.groceryMaintananceBackend.service;

import com.example.groceryMaintananceBackend.entity.*;
import com.example.groceryMaintananceBackend.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class serviceImpl implements service{
    @Autowired
    public ItemListRepository itemrepo;

    @Autowired
    public BoysRequestRepository boysitem;

    @Autowired
    public DayRequestRepository dayitem;

    @Autowired
    public GirlsRequestRepository girlsitem;

    @Autowired
    public ItemUpdateRepository itemupdaterepo;

    @Autowired
    public ReturnRepository returnlist;

    public ItemList addItemDetails(ItemList item) {
        return itemrepo.save(item);
    }

    @Override
    public List<ItemList> getItemDetails() {
        return itemrepo.findAll();
    }

    @Override
    public BoysRequest addBoysRequest(BoysRequest item) {
        return boysitem.save(item);
    }

    @Override
    public List<BoysRequest> getBoysRequest() {
        return boysitem.findAll();
    }

    @Override
    public DayRequest addDayRequest(DayRequest item) {
        return dayitem.save(item);
    }

    @Override
    public List<DayRequest> getDayRequest() {
        return dayitem.findAll();
    }

    @Override
    public GirlsRequest addGirlsRequest(GirlsRequest item) {
        return girlsitem.save(item);
    }

    @Override
    public List<GirlsRequest> getGirlsRequest() {
        return girlsitem.findAll();
    }

    @Override
    public ItemUpdate updateStock(ItemUpdate item) {
        return itemupdaterepo.save(item);
    }

    @Override
    public List<ItemUpdate> getupdateStock() {
        return itemupdaterepo.findAll();
    }

    @Override
    public ReturnList addReturnList(ReturnList item) {
        return returnlist.save(item);
    }

    @Override
    public List<ReturnList> getReturnList() {
        return returnlist.findAll();
    }

    @Override
    public BoysRequest editBoysIssue(Long id) {
        Optional<BoysRequest> existedData = boysitem.findById(id);
        if(existedData.isPresent()) {
            BoysRequest boyrequest = existedData.get();
            boyrequest.setStatus("Approved");
            boyrequest.setIssuedDate(LocalDate.now().toString());
            boysitem.save(boyrequest);
            return boyrequest;
        }
        return null;
    }

    @Override
    public List<BoysRequest> getPendingList() {
        return boysitem.findByStatus("pending");
    }

    @Override
    public GirlsRequest editGirlsIssue(Long id) {
        Optional<GirlsRequest> existedData = girlsitem.findById(id);
        if(existedData.isPresent()) {
            GirlsRequest girlsRequest = existedData.get();
            girlsRequest.setStatus("Approved");
            girlsRequest.setIssuedDate(LocalDate.now().toString());
            girlsitem.save(girlsRequest);
            return girlsRequest;
        }
        return null;
    }

    @Override
    public List<GirlsRequest> getGirlsPendingList() {
        return girlsitem.findByStatus("pending");
    }

    @Override
    public DayRequest editDayIssue(Long id) {
        Optional<DayRequest> existedData = dayitem.findById(id);
        if(existedData.isPresent()) {
            DayRequest dayRequest = existedData.get();
            dayRequest.setStatus("Approved");
            dayRequest.setIssuedDate(LocalDate.now().toString());
            dayitem.save(dayRequest);
            return dayRequest;
        }
        return null;
    }

    @Override
    public List<DayRequest> getDayPendingList() {
        return dayitem.findByStatus("pending");
    }
}