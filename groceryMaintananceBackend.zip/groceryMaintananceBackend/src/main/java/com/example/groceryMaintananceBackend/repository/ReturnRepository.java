package com.example.groceryMaintananceBackend.repository;

import com.example.groceryMaintananceBackend.entity.ReturnList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ReturnRepository extends JpaRepository<ReturnList,Long> {
}
