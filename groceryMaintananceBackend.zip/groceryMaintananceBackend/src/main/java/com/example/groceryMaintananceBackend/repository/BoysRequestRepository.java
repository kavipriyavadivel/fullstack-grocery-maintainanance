package com.example.groceryMaintananceBackend.repository;

import com.example.groceryMaintananceBackend.entity.BoysRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BoysRequestRepository extends JpaRepository<BoysRequest,Long> {
    List<BoysRequest> findByStatus(String status);
}
