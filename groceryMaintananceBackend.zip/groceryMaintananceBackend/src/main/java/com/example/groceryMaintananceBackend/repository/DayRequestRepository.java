package com.example.groceryMaintananceBackend.repository;

import com.example.groceryMaintananceBackend.entity.DayRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DayRequestRepository extends JpaRepository<DayRequest,Long> {
    List<DayRequest> findByStatus(String pending);
}