package com.example.groceryMaintananceBackend.service;

import com.example.groceryMaintananceBackend.entity.*;

import java.util.List;

public interface service {
    public ItemList addItemDetails(ItemList item) ;
    public List<ItemList> getItemDetails();
    public BoysRequest addBoysRequest(BoysRequest item);
    public List<BoysRequest> getBoysRequest();
    public DayRequest addDayRequest(DayRequest item);
    public List<DayRequest> getDayRequest();
    public GirlsRequest addGirlsRequest(GirlsRequest item);
    public List<GirlsRequest> getGirlsRequest();
    public ItemUpdate updateStock(ItemUpdate item);
    public List<ItemUpdate> getupdateStock();
    public ReturnList addReturnList(ReturnList item);
    public List<ReturnList> getReturnList();
    public BoysRequest editBoysIssue(Long id);
    List<BoysRequest> getPendingList();
    GirlsRequest editGirlsIssue(Long id);
    List<GirlsRequest> getGirlsPendingList();
    DayRequest editDayIssue(Long id);
    List<DayRequest> getDayPendingList();
}
