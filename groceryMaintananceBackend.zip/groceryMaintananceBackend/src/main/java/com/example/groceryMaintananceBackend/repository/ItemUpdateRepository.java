package com.example.groceryMaintananceBackend.repository;

import com.example.groceryMaintananceBackend.entity.ItemUpdate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ItemUpdateRepository extends JpaRepository<ItemUpdate,Long> {
}
