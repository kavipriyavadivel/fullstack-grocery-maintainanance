package com.example.groceryMaintananceBackend.controller;

import com.example.groceryMaintananceBackend.entity.*;
import com.example.groceryMaintananceBackend.service.serviceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/grocery")
public class Controller {

    @Autowired
    public serviceImpl serviceimp;

    @PostMapping("/add-item")
    public ResponseEntity<String> addItem(@RequestBody ItemList item){
        try {
            serviceimp.addItemDetails(item);
            return ResponseEntity.ok("Item details added successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An error occurred: " + e.getMessage());
        }
    }

    @GetMapping("/get-item")
    public List<ItemList> getitmdetail(){
        return serviceimp.getItemDetails();
    }

    @PostMapping("/boy-request")
    public ResponseEntity<String> boysRequest(@RequestBody BoysRequest item){
        serviceimp.addBoysRequest(item);
        return ResponseEntity.ok("Request submitted");
    }

    @GetMapping("/get-boy-request")
    public List<BoysRequest> getboyRequest(){
        return serviceimp.getBoysRequest();
    }

    @PostMapping("/day-request")
    public ResponseEntity<String> dayRequest(@RequestBody DayRequest item){
        serviceimp.addDayRequest(item);
        return ResponseEntity.ok("Request submitted");
    }

    @GetMapping("/get-day-request")
    public List<DayRequest> getdayRequest(){
        return serviceimp.getDayRequest();
    }

    @PostMapping("/girl-request")
    public ResponseEntity<String> girlRequest(@RequestBody GirlsRequest item){
        serviceimp.addGirlsRequest(item);
        return ResponseEntity.ok("Request submitted");
    }

    @GetMapping("/get-girl-request")
    public List<GirlsRequest> getgirlRequest(){
        return serviceimp.getGirlsRequest();
    }

    @PostMapping("/update-stock")
    public ResponseEntity<String> updateitem(@RequestBody ItemUpdate item){
        serviceimp.updateStock(item);
        return ResponseEntity.ok("Stock Updated");
    }

    @GetMapping("/get-updated-stock")
    public List<ItemUpdate> getupdateitem(){
        return serviceimp.getupdateStock();
    }

    @PostMapping("/add-return-list")
    public ResponseEntity<String> addreturn(@RequestBody ReturnList item){
        serviceimp.addReturnList(item);
        return ResponseEntity.ok("Item Returned");
    }

    @GetMapping("/get-return-list")
    public List<ReturnList> getreturn(){
        return serviceimp.getReturnList();
    }

    @PutMapping("/status-change/{id}")
    public ResponseEntity<BoysRequest> editstatus(@PathVariable Long id){
        BoysRequest boysRequest = serviceimp.editBoysIssue(id);
        return ResponseEntity.ok(boysRequest);
    }

    @GetMapping("/boy-pending-list")
    public ResponseEntity<List<BoysRequest>> getBoysPendingList()
    {
        List<BoysRequest> pendingList = serviceimp.getPendingList();
        return  ResponseEntity.ok(pendingList);
    }

    @PutMapping("/girl-status-change/{id}")
    public ResponseEntity<GirlsRequest> editgirlstatus(@PathVariable Long id){
        GirlsRequest girlsRequest = serviceimp.editGirlsIssue(id);
        return ResponseEntity.ok(girlsRequest);
    }

    @GetMapping("/girl-pending-list")
    public ResponseEntity<List<GirlsRequest>> getGirlsPendingList()
    {
        List<GirlsRequest> pendingList = serviceimp.getGirlsPendingList();
        return  ResponseEntity.ok(pendingList);
    }

    @PutMapping("/day-status-change/{id}")
    public ResponseEntity<DayRequest> editdaystatus(@PathVariable Long id){
        DayRequest dayRequest = serviceimp.editDayIssue(id);
        return ResponseEntity.ok(dayRequest);
    }

    @GetMapping("/day-pending-list")
    public ResponseEntity<List<DayRequest>> getDayPendingList()
    {
        List<DayRequest> pendingList = serviceimp.getDayPendingList();
        return  ResponseEntity.ok(pendingList);
    }
}
