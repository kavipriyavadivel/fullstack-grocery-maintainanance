package com.example.groceryMaintananceBackend.repository;

import com.example.groceryMaintananceBackend.entity.GirlsRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GirlsRequestRepository extends JpaRepository<GirlsRequest,Long> {
    List<GirlsRequest> findByStatus(String pending);
}