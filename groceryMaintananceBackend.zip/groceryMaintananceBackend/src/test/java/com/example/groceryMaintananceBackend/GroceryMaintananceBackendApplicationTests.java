package com.example.groceryMaintananceBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroceryMaintananceBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
